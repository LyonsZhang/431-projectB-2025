# 431-projectA-2024

This is the repository for the Project A instructions website for PQHS/CRSP/MPHP 431 in Fall 2024 with Professor Zhang

To actually view the Project A instructions and other materials, visit  https://lyonszhang.github.io/431-projectA-2024/

Visit https://thomaselove.github.io/431-2024 for links to all other materials related to the 431 course.